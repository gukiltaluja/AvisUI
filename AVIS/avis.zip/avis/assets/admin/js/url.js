
//var ip = "localhost";
//var ip = "http://198.169.0.90";
//var ip = "http://192.168.0.63";
var ip = "http://3.139.37.142";
//var ip = "masterModule";
//var port = "9095";
var port = "9093";
var masterService="/master_service";
//APIs

var tyreCreate = ip+":"+port+masterService+"/tyre/addTyre";
var allTyreList = ip+":"+port+masterService+"/tyre/getTyreById";
var getfuelTypeList =  ip+":"+port+masterService+"/fuelType/getfuelTypeList";
var manufacturarAdd =  ip+":"+port+masterService+"/manufacturer/addManufacturer";
var getManufacturerList =  ip+":"+port+masterService+"/manufacturer/getManufacturerList";
var getVehicleSegmentList =  ip+":"+port+masterService+"/vehicleSegment/getVehicleSegmentList";
var getModelById =  ip+":"+port+masterService+"/vehicleModel/getModelById";
var getModelManufacturer =  ip+":"+port+masterService+"/modal/getModelManufacturer";
var getFuelTankTypeList =  ip+":"+port+masterService+"/fuelTankType/getFuelTankTypeList";
var getVariantList =  ip+":"+port+masterService+"/variant/getVariantList";
var addVariant =  ip+":"+port+masterService+"/variant/addVariant";
var getUsageTypeList =  ip+":"+port+masterService+"/vehicleSegment/getUsageTypeList";
var getVariantsWithModelAndManufacturer =  ip+":"+port+masterService+"/variant/getVariantsWithModelAndManufacturer";
var getVariantList =  ip+":"+port+masterService+"/variant/getVariantList";

// start akhilesh

var getTyreList =  ip+":"+port+masterService+"/tyre/getTyreList";
// var addTyre =  ip+":"+port+masterService+"/tyre/addTyre";
var getUsageTypeList =  ip+":"+port+masterService+"/usageType/getUsageTypeList";
var addUsageType = ip+":"+port+masterService+"/usageType/addUsageType";

var getPartList =  ip+":"+port+masterService+"/part/getPartList";
var addPart = ip+":"+port+masterService+"/part/addPart";