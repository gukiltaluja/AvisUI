
 </ul>
    </div>
</div>
<footer>
	<div class="wrap">
    	<div class="columns23 bottom-link">
        	<ul>
            	<li class="col-2 fo">
                	<ul>
                    	<li><b class="large"  >ABOUT US</b></li>
                        <li><a href="<?php echo base_url('/webpage/about_us/')?>">Know Us</a></li>
                        <li><a href="#">Blog</a></li>
                        <li><a href="#">Gift Cards</a></li>
                        <li><a href="#">Contact Us</a></li>
                    </ul>
                    <ul>
                    	<li><b class="large">HELP</b></li>
                        <li><a href="#">Payments</a></li>
                        <li><a href="#">Saved Cards</a></li>
                        <li><a href="#">Shipping</a></li>
                        <li><a href="#">Cancellation & Returns</a></li>
                    </ul>
                    <ul>
                    	<li><b class="large">POLICY INFO</b></li>
                        <li><a href="<?php echo base_url('/webpage/privacy_policy/')?>">Privacy Policy</a></li>
                        <li><a href="#">Terms of Use</a></li>
                        <li><a href="#">Terms of Sale</a></li>
                        <li><a href="#">Copyright Policy</a></li>
                    </ul>
                    <ul>
                    	<li><b class="large">CONTACT US</b></li>
                        <li><a href="#">Call 24/7 (877) 841-2219</a></li>
                        <li><a href="#">Customer Service</a></li>
                        <li><a href="#">Email Us</a></li>
                    </ul>
                </li>
                <li class="col-3 email">
                	<p class="h">Email Sign Up</p>
					<p class="b large">Sign up & save 20% off your next purchase</p>
                    <div class="pr">
                    <input type="text" placeholder="Enter Your Email"/><button>SUBMIT</button>
                    </div>
                    
                </li>
            </ul>
        </div>
    	
        <div class="bottom columns23 width50">
        	<ul class="fo">
            	<li class="col-2 lh17em">Copyright &copy; 2015 the mobile indian. | Privacy policy.</li>
                <li class="col-3 social-media"><a class=" el el-facebook"></a> <a class=" el el-twitter"></a> <a class=" el el-youtube"></a> <a class=" el el-googleplus"></a> </li>
            </ul>
        </div>
    </div>
</footer>
</body>
</html>
