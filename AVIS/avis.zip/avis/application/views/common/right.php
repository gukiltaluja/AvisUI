 <li class="col-3">
	<p><a href="#"><img src="<?php echo ASSET_URL?>images/banner_l1.jpg" alt="" /></a></p>
</li>