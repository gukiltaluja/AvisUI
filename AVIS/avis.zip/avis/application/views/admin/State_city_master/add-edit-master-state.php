

 <!-- Start wrapper-->
 <div id="wrapper">
 
<div class="clearfix"></div>
  
  <div class="content-wrapper">
    <div class="container-fluid">

      <!--Start Dashboard Content-->
    
      
    <div class="row pt-2 pb-2">
        <div class="col-sm-9">
        <h4 class="page-title">Application</h4>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javaScript:void();">Basic Master
</a></li>
            <li class="breadcrumb-item"><a href="javaScript:void();">Master State</a></li>
         </ol>
     </div>
     </div>


     




     <div class="row">
      <div class="col-lg-12">
         <div class="card">
           <div class="card-body">
              <div class="buttondd" style="text-align: right;">
  <button type="submit" class="btn btn-primary save"><i class="fa fa-address-card-o" aria-hidden="true"></i>  &nbsp&nbspSave</button>
  <button type="submit" class="btn btn-primary cancel">Reset</button>

          
      </div>
           <!-- <div class="card-header text-uppercase">PRINCIPAL</div> -->
           <div class="pt-4">
            <form>
             <div class="row">
          
           <div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-3" placeholder="State Name ">
           </div>
           <div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="VAT On LR">
           </div>
           <div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="Service Tax">
           </div>
           <div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="State Address">
           </div>
           <div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="Swachh Bharat Cess">
           </div>
            <div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="Krishi Kalyan Cess">
           </div>
                <div class="form-group col-md-4">
        <div class="form-check padd mb-2">
                <input type="checkbox" class="form-check-input" id="check2" value="">
                <label class="form-check-label" for="check2">VAT input Credit available</label>
                </div>
           </div>
            <div class="form-group col-md-4">
        <div class="form-check padd mb-2">
                <input type="checkbox" class="form-check-input" id="check2" value="">
                <label class="form-check-label" for="check2">VAT input Credit to be Passed</label>
                </div>
           </div>  

             <div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="Tin No">
           </div>    

            <div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="LST Noo">
           </div>  
            <div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="Purchase Vat">
           </div>
            <div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="Sale Vat">
           </div>

            <div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="Accessirues Vat">
           </div>

            <div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="Invoice Footer">
           </div>

               <div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="State Code">
           </div>

               <div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="Pan No">
           </div>

<div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="Vat Reg No">
           </div>
           <div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="Service tax Reg No">
           </div>
           <div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="Education Cess">
           </div>
           <div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="Senior & Higher Educcation Cess">
           </div>

             <div class="form-group col-md-4">
        <div class="form-check padd mb-2">
                <input type="checkbox" class="form-check-input" id="check2" value="">
                <label class="form-check-label" for="check2">Trade Certificate</label>
                </div>
           </div>
            <div class="form-group col-md-4">
        <div class="form-check padd mb-2">
                <input type="checkbox" class="form-check-input" id="check2" value="">
                <label class="form-check-label" for="check2">VAT ON LR</label>
                </div>
           </div>  

            <div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="GST ON LR">
           </div>

            <div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="GST On FMS">
           </div>


<div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="GST on LR(Electrical Vehicle)">
           </div>

           <div class="form-group col-md-4">
            <input type="text" class="form-control" id="input-2" placeholder="GSTN Number">
           </div>

            <div class="form-group col-md-4">
        <div class="form-check padd mb-2">
                <input type="checkbox" class="form-check-input" id="check2" value="">
                <label class="form-check-label" for="check2">Union Territory</label>
                </div>
           </div>  


           
           <div class="form-group col-md-12">
        <div class="form-check padd mb-2">
                <input type="checkbox" class="form-check-input" id="check2" value="">
                <label class="form-check-label" for="check2">Active</label>
                </div>
           </div>
        </div>
          </form>
          </div>
         </div>
         </div>
       </div>

      </div><!--End Row-->
   
       


          <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <div class="table-responsive">
              <table id="example" class="table table-bordered">
                <thead>
                    <tr>
                        <th>View</th>
                        <th>State Name</th>
                        <th>VAT On LR</th>
                        <th>Service Tax</th>
                        <th>Active</th>
                        <th>Tools</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
<td><i class="fa fa-stop-circle-o" aria-hidden="true"></i></td>
<td>Andhra Prade</td>
<td>14.5</td>
<td>14</td>
<td>TRUE</td>
<td><i class="fa fa-plus-square" aria-hidden="true"></i>   <i class="fa fa-times" aria-hidden="true"></i></td>



</tr>
<tr>
<td><i class="fa fa-stop-circle-o" aria-hidden="true"></i></td>
<td>Andhra Prade</td>
<td>0</td>
<td>14</td>
<td>TRUE</td>
<td><i class="fa fa-plus-square" aria-hidden="true"></i>   <i class="fa fa-times" aria-hidden="true"></i></td>
</tr>
<tr>
<td><i class="fa fa-stop-circle-o" aria-hidden="true"></i></td>
<td>Assam</td>
<td>0</td>
<td>14</td>
<td>TRUE</td>
<td><i class="fa fa-plus-square" aria-hidden="true"></i>   <i class="fa fa-times" aria-hidden="true"></i></td>
</tr>
<tr>
<td><i class="fa fa-stop-circle-o" aria-hidden="true"></i></td>
<td>Bihar</td>
<td>13</td>
<td>14</td>
<td>TRUE</td>
<td><i class="fa fa-plus-square" aria-hidden="true"></i>   <i class="fa fa-times" aria-hidden="true"></i></td>
</tr>



<tr>
<td><i class="fa fa-stop-circle-o" aria-hidden="true"></i></td>
<td>Chandigarh</td>
<td>12</td>
<td>14</td>
<td>TRUE</td>
<td><i class="fa fa-plus-square" aria-hidden="true"></i>   <i class="fa fa-times" aria-hidden="true"></i></td>
</tr>


<tr>
<td><i class="fa fa-stop-circle-o" aria-hidden="true"></i></td>
<td>Chandigarh</td>
<td>0</td>
<td>14</td>
<td>TRUE</td>


<td><i class="fa fa-plus-square" aria-hidden="true"></i>   <i class="fa fa-times" aria-hidden="true"></i></td>
</tr>


<tr>
<td><i class="fa fa-stop-circle-o" aria-hidden="true"></i></td>
<td>Daman</td>
<td>0</td>
<td>14</td>
<td>TRUE</td>
<td><i class="fa fa-plus-square" aria-hidden="true"></i>   <i class="fa fa-times" aria-hidden="true"></i></td>
</tr>


<tr>
<td><i class="fa fa-stop-circle-o" aria-hidden="true"></i></td>
<td>Goa</td>
<td>0</td>
<td>14</td>
<td>TRUE</td>
<td><i class="fa fa-plus-square" aria-hidden="true"></i>   <i class="fa fa-times" aria-hidden="true"></i></td>
</tr>


<tr>
<td><i class="fa fa-stop-circle-o" aria-hidden="true"></i></td>
<td>Gujrat</td>
<td>5</td>
<td>14</td>
<td>TRUE</td>
<td><i class="fa fa-plus-square" aria-hidden="true"></i>   <i class="fa fa-times" aria-hidden="true"></i></td>
</tr>

<tr>
<td><i class="fa fa-stop-circle-o" aria-hidden="true"></i></td>
<td>Haryana</td>
<td>13</td>
<td>14</td>
<td>TRUE</td>
<td><i class="fa fa-plus-square" aria-hidden="true"></i>   <i class="fa fa-times" aria-hidden="true"></i></td>
</tr>
                    
                </tbody>
                <!--<tfoot>-->
                <!--    <tr>-->
                <!--        <th>View</th>-->
                <!--        <th>Manufacturer</th>-->
                <!--        <th>Model</th>-->
                <!--        <th>Tyre Size</th>-->
                <!--        <th>Active</th>-->
                <!--        <th>Tools</th>-->
                <!--    </tr>-->
                <!--</tfoot>-->
            </table>
            </div>
            </div>
          </div>
        </div>
      </div><!-- End Row-->
           
       <!--End Dashboard Content-->
      <!--start overlay-->
    <div class="overlay toggle-menu"></div>
  <!--end overlay-->
    </div>
    <!-- End container-fluid-->
    
    </div><!--End content-wrapper-->
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
     
  </div><!--End wrapper-->
  
