

<!-- Start wrapper-->
    <div id="wrapper">
           
        <div class="clearfix"></div>

        <div class="content-wrapper">
            <div class="container-fluid">
                <div class="row pt-2 pb-2">
                    <div class="col-sm-9">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javaScript:void();">Application</a></li>
                            <li class="breadcrumb-item"><a href="javaScript:void();">  Miscellaneous Invoice
</a></li>
                        </ol>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                               <div class="card-header text-uppercase">PRINCIPAL</div>
                                <form>
                                 
                                    <div class="row">
                                        <div class="form-group col-md-4">
                                            <input type="text" class="form-control" id="input-1" placeholder="Invoice Number" >
                                        </div>
                                       
                                        <div class="form-group col-md-4">
                                            <input type="text" class="form-control" id="input-2" placeholder="Invoice Date">
                                        </div>

                                        <div class="form-group col-md-4">
                                            <input type="text" class="form-control" id="input-2" placeholder="Client Name">
                                        </div>

                                           <div class="form-group col-md-4">
                                            <input type="text" class="form-control" id="input-2" placeholder="Client Number">
                                        </div>

                                          
                                      

                                       <div class="form-group col-md-4">
                                            <select id="inputState" class="form-control">
                                              <option>State</option>
                                              <option></option>
                                              <option></option>
                                              </select>
                                        </div>

                                         <div class="form-group col-md-4">
                                           <select id="inputState" class="form-control">
                                              <option>City</option>
                                              <option></option>
                                              <option></option>
                                              </select>
                                        </div>

                                        <div class="form-group col-md-4">
                                            <input type="text" class="form-control" id="input-2" placeholder="Contract Number">
                                        </div>

                                        <div class="form-group col-md-4">
                                            <input type="text" class="form-control" id="input-2" placeholder="Model Name">
                                        </div>

                                        <div class="form-group col-md-4">
                                            <input type="text" class="form-control" id="input-2" placeholder="Registration Number">
                                        </div>

                                        <div class="form-check paddss col-md-3">
                                          <input type="checkbox" class="form-check-input margin-t" id="check2" value="">
                                          <label class="form-check-label margin-t" for="check2">Vehicle To Be Exported</label>
                                          </div>

                                         <div class="form-group col-md-4">
                                           <textarea class="form-control" id="val-suggestions" name="val-suggestions" rows="5" placeholder="Address"></textarea>
                                        </div>





                                    </div>
                                    <div class="DETAILS-CODE">
                                    <div class="row">
                                       <div class="card-header text-uppercase">DETAILS</div>

                            <table id="example" class="table table-bordered table-responsive">
                <thead>
<tr>
<th width="285">CODE</th>
<th width="173">DESCRIPTION</th>
<th width="186">QUANTITY</th>
<th width="184">UNIT PRICE</th>
<th width="150">TOTAL PRICE EXCLUDING TAX</th>
<th width="172">TOTAL PRICE EXCLUDING TAX</th>
<th width="184">GST</th>
<th width="150">TOTAL INCLUDING TAX</th>
<th width="172">TOTAL EXCLUDING TAX</th>
</tr>
</thead>
<tbody>
<tr>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>


</tbody>
</table>
                                    </div>
                                  </div>

                                    <div class="row">
                                        <div class="form-group col-md-4">
                                            <input type="text" class="form-control" id="input-1" placeholder="Total Including Tax" >
                                        </div>
                                       

                                       <div class="form-group col-md-4">
                                           <textarea class="form-control" id="val-suggestions" name="val-suggestions" rows="5" placeholder=" Remarks"></textarea>
                                        </div>
                                       



                                    </div>
                                    <div class="button">

 <button type="submit" class="btn btn-primary save">New Invoice</button>
  <button type="submit" class="btn btn-primary save">Credit Note Invoice</button>
   <button type="submit" class="btn btn-primary save">Print</button>
    <button type="submit" class="btn btn-primary save">SAVE</button>
     <button type="submit" class="btn btn-primary cancel">CANCEL</button>
        </div>

                                    
                                      
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                             
        <!-- End container-fluid-->

    </div>
    <!--End content-wrapper-->
    <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->

    </div>
    <!--End wrapper-->