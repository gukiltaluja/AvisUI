<!-- Start wrapper-->
 <div id="wrapper">
 
  <!--Start sidebar-wrapper-->
   <div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
     <div class="brand-logo">
       <h5 class="logo-text">AVIS</h5>
   </div>
   <ul class="sidebar-menu do-nicescrol">
    <li>
        <a href="<?php echo base_url('/')?>" class="waves-effect">
         <i class="icon-home"></i> <span>Dashboard</span>
        </a>
      </li>
      <li>
         <a href="<?php echo base_url('/')?>" class="waves-effect">
           <i class="icon-layers"></i> <span>Masters</span> <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="sidebar-submenu">
                  <li><a href="<?php echo base_url('admin/master/addeditmaster')?>">Client Masters</a></li>
                  <li><a href="<?php echo base_url('admin/ordermaster/addeditomaster')?>">Order Masters</a></li>
                  <li><a href="<?php echo base_url('admin/delivery/addeditdelivery')?>">Delivery Module</a></li>
        </ul>
      </li>
      
      
       <li>
        <a href="javaScript:void();" class="waves-effect">
          <i class="fa fa-share"></i> <span>Basic Master</span>
          <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="sidebar-submenu">
          <li><a href="javaScript:void();"> </a></li>
          <li>
            <a href="javaScript:void();"><i class="fa fa-circle-o"></i> COMPONENT MASTER <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="sidebar-submenu">
               <li><a href="<?php echo base_url('admin/tyre/addedittyre')?>">  <i class="fa fa-circle-o"></i> Tyre</a></li>
                            <li><a href="<?php echo base_url('admin/usagetype/addeditusagetype')?>"> <i class="fa fa-circle-o"></i> Usage Type</a></li>
                            <li><a href="<?php echo base_url('admin/carprice/addeditcarprice')?>"> <i class="fa fa-circle-o"></i> Car Price</a></li>
                            <li><a href="<?php echo base_url('admin/part/addeditpart')?>"> <i class="fa fa-circle-o"></i> Part</a></li>
                            <li><a href="<?php echo base_url('admin/parttype/addeditparttype')?>"> <i class="fa fa-circle-o"></i> Part Type</a></li>
                            <li><a href="<?php echo base_url('admin/rv/addeditrv')?>"> <i class="fa fa-circle-o"></i> RV</a></li>
                            <li><a href="<?php echo base_url('admin/rmtp/addeditrmtp')?>"> <i class="fa fa-circle-o"></i> RMTP</a></li>
                            <li><a href="<?php echo base_url('admin/fueltype/addeditfueltype')?>"> <i class="fa fa-circle-o"></i> Fuel Type</a></li>
                            <li><a href="<?php echo base_url('admin/fueltanktype/addeditfueltanktype')?>"> <i class="fa fa-circle-o"></i> Fuel Tank Type</a></li>
                            <li><a href="<?php echo base_url('admin/vehiclesegment/addeditvehiclesegment')?>"> <i class="fa fa-circle-o"></i> Vehicle Segment</a></li>
                            <li><a href="<?php echo base_url('admin/colorcode/addeditcolorcode')?>"> <i class="fa fa-circle-o"></i> Color Code</a></li>
            </ul>
          </li>
          
        </ul>
        <ul class="sidebar-submenu">
          <li><a href="javaScript:void();"> </a></li>
          <li>
            <a href="javaScript:void();"><i class="fa fa-circle-o"></i> BANK MASTER <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="sidebar-submenu">
                            <li><a href="<?php echo base_url('admin/bankmaster/addeditbankmaster')?>"> <i class="fa fa-circle-o"></i> Bank</a></li>           
            </ul>
          </li>
        </ul>
          <ul class="sidebar-submenu">
          <li><a href="javaScript:void();"> </a></li>
          <li>
            <a href="javaScript:void();"><i class="fa fa-circle-o"></i> SUPPLIER MASTER <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="sidebar-submenu">
                           <li><a href="<?php echo base_url('admin/suppliermastersupplier/addeditsuppliermasters')?>"><i class="fa fa-circle-o"></i>  Supplier</a></li>
                            <li><a href="<?php echo base_url('admin/mastersupplierlocationdetails/addeditmastersupplierlocation')?>"><i class="fa fa-circle-o"></i>  Supplier Location</a></li>
                            <li><a href="<?php echo base_url('admin/mastersuppliertypedetails/addeditmastersuppliertype')?>"><i class="fa fa-circle-o"></i>  Supplier Details</a></li>           
            </ul>
          </li>
        </ul>
         <ul class="sidebar-submenu">
          <li><a href="javaScript:void();"> </a></li>
          <li>
            <a href="javaScript:void();"><i class="fa fa-circle-o"></i> VARIANT MASTER <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="sidebar-submenu">
                            <li><a href="<?php echo base_url('admin/mastervariantdetails/addeditmastervariant')?>"><i class="fa fa-circle-o"></i> Variant </a></li>           
            </ul>
          </li>
        </ul>
         
         <ul class="sidebar-submenu">
          <li><a href="javaScript:void();"> </a></li>
          <li>
            <a href="javaScript:void();"><i class="fa fa-circle-o"></i> MANUFACTURER MATER <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="sidebar-submenu">
                             <li><a href="<?php echo base_url('admin/mastermenufacturerdetails/addeditmastermenufacturer')?>"> <i class="fa fa-circle-o"></i> Manufacturer </a></li>
                               <li><a href="<?php echo base_url('admin/mastermenufacturercontact/addeditmastermenufacturerc')?>"><i class="fa fa-circle-o"></i>Manufacture Contact </a></li>           
            </ul>
          </li>
        </ul>
         <ul class="sidebar-submenu">
          <li><a href="javaScript:void();"> </a></li>
          <li>
            <a href="javaScript:void();"><i class="fa fa-circle-o"></i> INSURANCE TAX MASTER <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="sidebar-submenu">
                             <li><a href="<?php echo base_url('admin/masterinsurancecompany/addeditmasterinsurancecomp')?>"> <i class="fa fa-circle-o"></i>Insurance Company </a></li> 
                           <li><a href="<?php echo base_url('admin/insuranceidv/addeditinsuranceidv')?>"><i class="fa fa-circle-o"></i> Insurance IDV  </a></li>
                           <li><a href="<?php echo base_url('admin/masterroadtypetax/addeditmasterroadtypetx')?>"><i class="fa fa-circle-o"></i> Road Type Tax </a></li>
                           <li><a href="<?php echo base_url('admin/masterinsurancethirdparty/addeditInsuranceThirdParty')?>"><i class="fa fa-circle-o"></i>Insurance Third Party</a></li>
                           <li><a href="#"><i class="fa fa-circle-o"></i> Insurance Zone</a></li>   
                           <li><a href="<?php echo base_url('admin/masterinsurancezonevehicle/addeditInsuranceZoneVehicle')?>"><i class="fa fa-circle-o"></i> Insurance Zone Vehicle Segment Car CC </a></li>  
                           <li><a href="<?php echo base_url('admin/masteraccessoriestype/addeditaccessoriestype')?>"><i class="fa fa-circle-o"></i> Accessories Type </a></li>        
            </ul>
          </li>
        </ul>

        <ul class="sidebar-submenu">
          <li><a href="javaScript:void();"> </a></li>
          <li>
            <a href="javaScript:void();"><i class="fa fa-circle-o"></i> SERVICES MASTER <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="sidebar-submenu">
                             <li><a href="#"><i class="fa fa-circle-o"></i> Service Name</a></li>
                               <li><a href="#"><i class="fa fa-circle-o"></i> Car Category</a></li>   
                               <li><a href="#"><i class="fa fa-circle-o"></i> car category service cost</a></li>  
                                <li><a href="#"><i class="fa fa-circle-o"></i> Accessories</a></li>      
            </ul>
          </li>
        </ul>

         <ul class="sidebar-submenu">
          <li><a href="javaScript:void();"> </a></li>
          <li>
            <a href="javaScript:void();"><i class="fa fa-circle-o"></i> STATE-CITY MASTER <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="sidebar-submenu">
                             <li><a href="<?php echo base_url('admin/masterstate/addeditstate')?>"><i class="fa fa-circle-o"></i> State</a></li>
                               <li><a href="<?php echo base_url('admin/mastercity/addeditcity')?>"><i class="fa fa-circle-o"></i> City</a></li>   
                               <li><a href="<?php echo base_url('admin/cityunlimited/addeditcityunlimited')?>"><i class="fa fa-circle-o"></i> City Unlimited Usage</a></li>  
                                <li><a href="<?php echo base_url('admin/citydocument/addeditcitydoc')?>"><i class="fa fa-circle-o"></i> City Document</a></li>  
                                <li><a href="<?php echo base_url('admin/cityservice/addeditcityservice')?>"><i class="fa fa-circle-o"></i> City Services</a></li>     
            </ul>
          </li>
        </ul>
         <ul class="sidebar-submenu">
          <li><a href="javaScript:void();"> </a></li>
          <li>
            <a href="javaScript:void();"><i class="fa fa-circle-o"></i> MODEL MASTER <i class="fa fa-angle-left pull-right"></i></a>
            <ul class="sidebar-submenu">
                             <li><a href="#"><i class="fa fa-circle-o"></i> Model</a></li>
                               <li><a href="#"><i class="fa fa-circle-o"></i> Service Schedule</a></li>    
            </ul>
          </li>
        </ul>

      </li>
      <!--<li>-->
      <!--   <a href="index.html" class="waves-effect">-->
      <!--     <i class="icon-layers"></i> <span>Basic Master</span> <i class="fa fa-angle-left pull-right"></i>-->
      <!--  </a>-->
      <!--  <ul class="sidebar-submenu">-->
      <!--   <li><a href="tyre.html">Tyre</a></li>-->
      <!--                      <li><a href="usage-type.html">Usage Type</a></li>-->
      <!--                      <li><a href="car-price.html">Car Price</a></li>-->
      <!--                      <li><a href="part.html">Part</a></li>-->
      <!--                      <li><a href="part-type.html">Part Type</a></li>-->
      <!--                      <li><a href="rv.html">RV</a></li>-->
      <!--                      <li><a href="rmtb.html">RMTB</a></li>-->
      <!--                      <li><a href="fuel-type.html">Fuel Type</a></li>-->
      <!--                      <li><a href="fuel-tank-type.html">Fuel Tank Type</a></li>-->
      <!--                      <li><a href="vehicle-segment.html">Vehicle Segment</a></li>-->
      <!--                      <li><a href="color-code.html">Color Code</a></li>-->
      <!--                      <li><a href="bank-master.html">Bank Master</a></li>-->
      <!--                      <li><a href="supplier-master-supplier.html">Supplier Master Supplier</a></li>-->
      <!--                      <li><a href="master-supplier-location-details.html">Supplier Location Details</a></li>-->
      <!--                      <li><a href="master-supplier-type-details.html">Supplier Type Details</a></li>-->
                            <!--<li><a href="insurance-details.html">Insurance Details</a></li>-->
      <!--                      <li><a href="master-insurance-zone-vehicle-segment-car-cc.html">Insurance Zone Vehicle Segment Car CC </a></li>-->
      <!--                      <li><a href="insurance-idv-details.html">Insurance IDV Details </a></li>-->
      <!--                       <li><a href="master-road-type-tax-details.html">Master RoadType Tax Details</a></li>-->
      <!--                        <li><a href="master-insurance-company-details.html">Master Insurance Company Details</a></li>-->
      <!--                        <li><a href="master-insurance-third-party.html">Master Insurance Third Party</a></li>-->
      <!--                        <li><a href="master-accessories-type-details.html">Master Accessories Type Details</a></li>-->
      <!--                        <li><a href="master-menufacturer-details.html">Master Manufacturer Details</a></li>-->
      <!--                         <li><a href="Master-Menufacturer-Contact-details.html">Master Manufacture Contact Details</a></li>-->
      <!--                          <li><a href="master-variant-details.html">Master Variant Details</a></li>-->
      <!--                           <li><a href="master-model-details.html">Master Model Details</a></li>-->
      <!--                             <li><a href="master-service-schedule-details.html">Master Service Schedule Details</a></li>-->
      <!--                              <li><a href="master-service-details.html">Master Service Details </a></li>-->
      <!--                               <li><a href="master-city-category-details.html">Master City Category Details </a></li>-->
      <!--                                <li><a href="master-category-schedule-details.html">Master Category Schedule Details </a></li>-->
      <!--                                 <li><a href="master-accessories-details.html">Master Accessories Details </a></li>-->
      <!--  </ul>-->
      <!--</li>-->
      <li>
        <a href="<?php echo base_url('admin/quotationmodule/addeditquotation')?>" class="waves-effect">
         <i class="icon-layers"></i> <span>Quotation Module</span>
        </a>
      </li>

      <li>
         <a href="index.html" class="waves-effect">
           <i class="icon-layers"></i> <span>Invoicing Module</span> <i class="fa fa-angle-left pull-right"></i>
        </a>
        <ul class="sidebar-submenu">
         <li><a href="<?php echo base_url('admin/invoicingmodule/addeditinvoicingmod')?>"><i class="fa fa-circle-o"></i> Invoicing Module</a></li>
         <li><a href="<?php echo base_url('admin/miscellaneousinvoice/addeditmiscellinvoice')?>"> <i class="fa fa-circle-o"></i>  Miscellaneous Invoice</a></li>          
         <li><a href="<?php echo base_url('admin/remarketinginvoices/addeditremarketing')?>"> <i class="fa fa-circle-o"></i>  Re-marketing Invoices</a></li>  
        </ul>
      </li>
   
    </ul>
      
   
   </div>
   <!--End sidebar-wrapper-->