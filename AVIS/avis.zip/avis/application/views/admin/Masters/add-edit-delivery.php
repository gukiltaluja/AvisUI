
  <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Registration Certificate</h5>
                                                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                         <form>
              <div class="row">
           <div class="form-group col-md-4">
               <label for="exampleInputEmail1">Registration NO.</label>
            <input type="text" class="form-control" id="input-1" placeholder="Registration NO.">
           </div>
           <div class="form-group col-md-4">
               <label for="exampleInputEmail1">Date Of Registration</label>
            <input type="date" class="form-control" id="input-3">
           </div>
           <div class="form-group col-md-4">
               <label for="exampleInputEmail1">Validity Date</label>
            <input type="date" class="form-control" id="input-1">
           </div>
           <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Vehicle Brand">
           </div>
           <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Vehicle Type">
           </div>
           <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Vehicle Model">
           </div>
           <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Vehicle Colour">
           </div>
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Engine Model Frame">
           </div>
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Gross Weight (Kg)">
           </div>
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Net Weight (Kg)">
           </div>
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Capacity (Load)">
           </div>
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Capacity (Passenger)">
           </div>
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Cerificate Number">
           </div>
            
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Manufacture Year">
           </div>
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Logo">
           </div>
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Engine Power (H.p.)">
           </div>
           <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Engine Size (Cmᵌ)">
           </div>
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Fuel Type">
           </div>
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Technical Inspection">
           </div>
         
        </div>
          </form>
                                                </div>
                                                <div class="modal-footer">
                                                   <div class="button">
    
 <button type="submit" class="btn btn-primary cancel">CANCEL</button>
 <button type="submit" class="btn btn-primary save">SAVE</button>
 </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

<!-- Start wrapper-->
 <div id="wrapper">
 
<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">

      <!--Start Dashboard Content-->	  
		  
		<div class="row pt-2 pb-2">
        <div class="col-sm-9">
        <h4 class="page-title">Application</h4>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javaScript:void();">Masters</a></li>
            <li class="breadcrumb-item"><a href="javaScript:void();">Delivery Masters</a></li>
         </ol>
     </div>
     </div>

      <div class="row">
      <div class="col-lg-12">
         <div class="card">
           <div class="card-body">
           <div class="card-header text-uppercase">PRINCIPAL</div>
           <hr>
            <form>
              <div class="row">
           <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Order Number">
           </div>
           <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-3" placeholder="Contract Number">
           </div>
           <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-2" placeholder="Client Name">
           </div>
           
           <div class="form-group col-md-3">
                    <div class="form-check padd mb-2">

                <input type="checkbox" class="form-check-input" id="check2" value="">
                <label class="form-check-label" for="check2">Sale And Lease Back</label>
                </div>
           </div>
         
        </div>
          </form>
         </div>
         </div>
       </div>
      </div><!--End Row-->

 <div class="row">
       

        <div class="col-lg-12">
           <div class="card">
              <div class="card-body"> 
                <ul class="nav nav-tabs nav-tabs-danger nav-justified top-icon">
                  <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#tabe-17"><span class="hidden-xs">VEHICLE </span></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#tabe-18"><span class="hidden-xs">EXTRA ITEM</span></a>
                  </li>
                 <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#tabe-19"><span class="hidden-xs">ORDER</span></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#tabe-20"><span class="hidden-xs"> DELIVERY</span></a>
                  </li>                  
                </ul>

                <!-- Tab panes -->
                <div class="tab-content">
                  <div id="tabe-17" class="container tab-pane active">
                          <form>
            <div class="row">
           <div class="form-group col-md-3">
            <input type="text" class="form-control" id="company-profile" placeholder="Model">
           </div>
           <div class="form-group col-md-3">
 
            <input type="text" class="form-control" id="input-2" placeholder="Colour">
           </div>

 <div class="form-group col-md-3">
   
           <select id="inputState" class="form-control">
        <option selected>Ambience Interior</option>
        <option>...</option>
      </select>
           </div>
           
           <div class="col-md-12">
    <div class="font-as">
        <i class="fa fa-eye" aria-hidden="true"></i>
        </div>
    </div>
             <div class="col-md-12">        

</div>          
           <div class="form-group col-md-6">
            
           <textarea class="form-control" placeholder="Address"></textarea>
           </div>
           
            <div class="form-group col-md-3">
           <select id="inputState" class="form-control">
        <option selected>State</option>
        <option>...</option>
      </select>
           </div>          
           
           <div class="form-group col-md-3">
          <select id="inputState" class="form-control">
        <option selected>City</option>
        <option>...</option>
      </select>
           </div> 
          
        </div>
    
<div class="button">
    
 <button type="submit" class="btn btn-primary cancel">CANCEL</button>
 <button type="submit" class="btn btn-primary save">SAVE</button>
 
          </form>
        </div>

                  </div>
                  <div id="tabe-18" class="container tab-pane fade">
                                                                 <form>
             <div class="row">
           <div class="form-group col-md-2">
            <input type="text" class="form-control" id="company-profile" placeholder="Serial No.">
           </div>
           <div class="form-group col-md-2">
  <select id="inputState" class="form-control">
        <option selected>Item</option>
        <option>...</option>
      </select>
           </div>
           <div class="form-group col-md-2">
   
            <input type="text" class="form-control" id="input-3" placeholder="Item No.">
           </div>
           <div class="form-group col-md-2">
            
            <input type="text" class="form-control" id="input-4" placeholder="Cost">
           </div>
           <div class="form-group col-md-2">
            
            <input type="text" class="form-control" id="input-4" placeholder="Cost Inciuding Tex">
           </div>   
         
        </div>  
         

<div class="button">
 <button type="submit" class="btn btn-primary cancel">CANCEL</button>
 <button type="submit" class="btn btn-primary save">SAVE</button>
 </div>
          </form>
                  </div>
                <div id="tabe-19" class="container tab-pane fade">
                     <form>
                                                  <h4 style="padding-top: 20px;">SUPPLIER</h4>

              <div class="row">
           <div class="form-group col-md-2">
            <input type="text" class="form-control" id="input-1" placeholder="Supplier Code">
           </div>
           <div class="form-group col-md-2">
 
            <input type="text" class="form-control" id="input-2" placeholder="Name">
           </div>
          
           <div class="form-group col-md-2">
            
            <input type="text" class="form-control" id="input-4" placeholder="Address">
           </div>
           
            <div class="form-group col-md-2">
             <select id="inputState" class="form-control">
        <option selected>State</option>
        <option>...</option>
      </select>
           </div>
            <div class="form-group col-md-2">
             <select id="inputState" class="form-control">
        <option selected>City</option>
        <option>...</option>
      </select>
           </div>
            
            <div class="form-group col-md-2">
            
            <input type="text" class="form-control" id="input-4" placeholder="Supplier Or. No.">
           </div>           
        </div>
        <h4 style="padding-top: 20px;">INFORMATION</h4>

              <div class="row">
           <div class="form-group col-md-3">
               
               <label for="Supplier">Supplier Delivery Date</label>
            <input type="date" class="form-control" id="input-1" placeholder="Supplier Code">
           </div>
           <div class="form-group col-md-3">
           <label for="Supplier">Client Delivery Date</label>
            <input type="date" class="form-control" id="input-2">
           </div>
          
           <div class="form-group col-md-3">
            <label for="Supplier">Supplier Code</label>
            <input type="date" class="form-control" id="input-4"  placeholder="Supplier Code">
           </div>
           <div class="form-group col-md-3">
            <label for="Supplier">Delivery Address</label>
            <input type="text" class="form-control" id="input-4" placeholder="Delivery Address">
           </div>

            <div class="form-group col-md-3">

                <input type="checkbox" class="form-check-input" id="check2" value="">
                <label class="form-check-label" for="check2">Client Pick-up</label>
                
           </div>

            <div class="form-group col-md-3">

                <input type="checkbox" class="form-check-input" id="check2" value="">
                <label class="form-check-label" for="check2"> Showroom To Delivery</label>
                
           </div>


            

           
        </div>
        <h4 style="padding-top: 20px;">INVOCICING CENTER</h4>

              <div class="row">
           <div class="form-group col-md-2">
             <textarea class="form-control" placeholder="Address"></textarea>
           </div>
           <div class="form-group col-md-2">
 
            <input type="text" class="form-control" id="input-2" placeholder="Pin Code">
           </div>
          
           <div class="form-group col-md-2">
             <select id="inputState" class="form-control">
        <option selected>Country</option>
        <option>...</option>
      </select>
           </div>
            <div class="form-group col-md-2">
             <select id="inputState" class="form-control">
        <option selected>State</option>
        <option>...</option>
      </select>
           </div>
             <div class="form-group col-md-2">
             <select id="inputState" class="form-control">
        <option selected>City</option>
        <option>...</option>
      </select>
           </div>
            <div class="form-group col-md-2">
            
            <input type="text" class="form-control" id="input-4" placeholder="GSTIN">
           </div>

            <div class="form-group col-md-6">
            
           <textarea class="form-control" placeholder="Remarks"></textarea>
           </div>


           
        </div>
        <div class="button">
 <button type="submit" class="btn btn-primary cancel">CANCEL</button>
 <button type="submit" class="btn btn-primary save">SAVE</button>
</div>
          </form>
                  </div>

                   <div id="tabe-20" class="container tab-pane fade">
                       <form>
            <h4 style="padding-top: 20px;">SUPPLIER</h4>
             <div class="row">
           <div class="form-group col-md-3">
               <label for="exampleInputEmail1">Supplier Delivery Date</label>
            <input type="date" class="form-control" id="company-profile">
           </div>
           <div class="form-group col-md-3">
            <label for="exampleInputEmail1">Client Delivery Date</label>
            <input type="date" class="form-control" id="company-profile" >
           </div>
           <div class="form-group col-md-2">
           <label for="exampleInputEmail1">Mileage</label>
            <input type="text" class="form-control" id="input-3" placeholder="Mileage">
           </div>
           <div class="form-group col-md-2">
             <label for="exampleInputEmail1">Receiver Name</label>
            <input type="text" class="form-control" id="input-4" placeholder="Receiver Name">
           </div>
           <div class="form-group col-md-2">
             <label for="exampleInputEmail1">Designation</label>
            <input type="text" class="form-control" id="input-4" placeholder="Designation">
           </div>
           


          
        </div>
        
         <h4 style="padding-top: 20px;">CLIENT</h4>
             <div class="row">
           <div class="form-group col-md-3">
               <label for="exampleInputEmail1">Planned Delivery Date</label>
            <input type="date" class="form-control" id="company-profile">
           </div>
           <div class="form-group col-md-3">
               <label for="exampleInputEmail1">Delivery Address</label>
            <input type="date" class="form-control" id="company-profile">
           </div>
           <div class="form-group col-md-2">
           <label for="exampleInputEmail1">Driver Name</label>
            <input type="text" class="form-control" id="input-3" placeholder="Driver Name">
           </div>
           <div class="form-group col-md-4">
            <label for="exampleInputEmail1">Remarks</label>
            <textarea class="form-control" placeholder="Remarks"></textarea>
           </div>          
        </div>
       
         

<div class="button">
    <button type="button" class="btn btn-primary DISCUSSION" data-toggle="modal" data-target=".bd-example-modal-lg">Click To Open Registration Certificate</button>
 <button type="submit" class="btn btn-primary cancel">CANCEL</button>
 <button type="submit" class="btn btn-primary save">SAVE</button>
 </div>
          </form>
                  </div>
                 
                </div>
              </div>
           </div>
        </div>
      </div><!--End Row-->
      

       <!--End Dashboard Content-->
      <!--start overlay-->
	  <div class="overlay toggle-menu"></div>
	<!--end overlay-->
    </div>
    <!-- End container-fluid-->
    
    </div><!--End content-wrapper-->
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->	
   
  </div><!--End wrapper-->
