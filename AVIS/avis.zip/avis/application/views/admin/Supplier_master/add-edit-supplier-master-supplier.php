 

<!-- Start wrapper-->
 <div id="wrapper">
  
<div class="clearfix"></div>
  
  <div class="content-wrapper">
    <div class="container-fluid">

      <!--Start Dashboard Content-->
    
      
    <div class="row pt-2 pb-2">
        <div class="col-sm-9">
        <h4 class="page-title">Application</h4>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javaScript:void();">Basic Master
</a></li>
            <li class="breadcrumb-item"><a href="javaScript:void();">Supplier Master Supplier</a></li>
         </ol>
     </div>
     </div>


     
  <div class="row">
      <div class="col-lg-12">
         <div class="card">
           <div class="card-body">
              
           <!-- <div class="card-header text-uppercase">PRINCIPAL</div> -->
           <div class="pt-4">
            <form>
             <div class="row">
         

            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Bank Name">
           </div>
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Legal Name">
           </div>
           <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Supplier Address">
           </div>
            <div class="form-group col-md-3">
            <select id="inputState" class="form-control">
              <option>KYC</option>
        <option></option>
        <option></option>
        </select>
           </div>
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Supplier Phone">
           </div>
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="GSTN Number">
           </div>
            <div class="form-group col-md-3">
            <input type="date" class="form-control" id="input-1" placeholder="Renewal Date">
           </div>
            
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Account Name">
           </div>
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="IFSC Code">
           </div>
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="PAN No">
           </div>
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Tin No">
           </div>
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Agreed Discount On Service Parts">
           </div>

            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Agreed Discount On Service Labor">
           </div>
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Agreed Discount On Accidental Parts">
           </div>
            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Agreed Discount On Accidental Labor">
           </div>
            <div class="form-group col-md-3">
             <select id="inputState" class="form-control">
              <option>Credit On New Car Purchase (In Days)</option>
        <option></option>
        <option></option>
        </select>

           </div>

           

            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Account Email ID">
           </div>

            <div class="form-group col-md-3">
            <input type="text" class="form-control" id="input-1" placeholder="Workshop Email ID">
           </div>

           <div class="form-group col-md-12">
        <div class="form-check padd mb-2">
                <input type="checkbox" class="form-check-input" id="check2" value="">
                <label class="form-check-label" for="check2">Relationship Workshop</label>
                </div>
           </div>
           <div class="form-group col-md-12">
        <div class="form-check padd mb-2">
                <input type="checkbox" class="form-check-input" id="check2" value="">
                <label class="form-check-label" for="check2">Active</label>
                </div>
           </div>
        </div>
          </form>
          </div>
          <div class="buttondd" style="text-align: right;">
  <button type="submit" class="btn btn-primary save"><i class="fa fa-address-card-o" aria-hidden="true"></i>  &nbsp&nbspSave</button>
  <button type="submit" class="btn btn-primary cancel">Reset</button>

          
      </div>
         </div>
         </div>
       </div>

      </div><!--End Row-->

       <div class="row">
      <div class="col-lg-12">
         <div class="card">
           <div class="card-body">
           <!-- <div class="card-header text-uppercase">PRINCIPAL</div> -->
           <div class="pt-4">
            <form>
             <div class="row">
           <div class="form-group col-md-12">
             <select id="inputState" class="form-control">
              <option>Supplier Name</option>
        <option></option>
        <option></option>
        </select>

           </div>
           
                     
          
        </div>
          </form>
          </div>
         </div>
         </div>
       </div>

      </div><!--End Row-->
       


        
       
       
       

       <!--End Dashboard Content-->
      <!--start overlay-->
    <div class="overlay toggle-menu"></div>
  <!--end overlay-->
    </div>
    <!-- End container-fluid-->
    
    </div><!--End content-wrapper-->
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
  
  <!--Start footer-->
  <footer class="footer">
      <div class="container">
        <div class="text-center">
          © All Rights Reserved. Amazin Automation Solution India Pvt. Ltd.
        </div>
      </div>
    </footer>
  <!--End footer-->
   
  </div><!--End wrapper-->
  
