

<!-- Start wrapper-->
 <div id="wrapper">
 
<div class="clearfix"></div>
  
  <div class="content-wrapper">
    <div class="container-fluid">

      <!--Start Dashboard Content-->
    
      
    <div class="row pt-2 pb-2">
        <div class="col-sm-9">
        <h4 class="page-title">Application</h4>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javaScript:void();">Basic Master
</a></li>
            <li class="breadcrumb-item"><a href="javaScript:void();">Master Supplier Type Details</a></li>
         </ol>
     </div>
     </div>


  <div class="row">
      <div class="col-lg-12">
         <div class="card">
           <div class="card-body">
              
           <!-- <div class="card-header text-uppercase">PRINCIPAL</div> -->
           <div class="pt-4">
            <form>
             <div class="row">
           <div class="form-group col-md-12">
            <input type="text" class="form-control" id="input-1" placeholder="Supplier Type Name">
           </div>
           
                     
           
           <div class="form-group col-md-6">
        <div class="form-check padd mb-2">
                <input type="checkbox" class="form-check-input" id="check2" value="">
                <label class="form-check-label" for="check2">Active</label>
                </div>
           </div>
        </div>
          </form>
          </div>
          <div class="buttondd" style="text-align: right;">
  <button type="submit" class="btn btn-primary save"><i class="fa fa-address-card-o" aria-hidden="true"></i>  &nbsp&nbspSave</button>
  <button type="submit" class="btn btn-primary cancel">Reset</button>

          
      </div>
         </div>
         </div>
       </div>

      </div><!--End Row-->
       


 <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <div class="table-responsive">
              <table id="example" class="table table-bordered">
                <thead>
                    <tr>
                       <th data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;View &quot;}">View</th>
<th data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;Service&quot;}">Service</th>
<th data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;Active&quot;}">Active</th>
<th data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;Tools&quot;}">Tools</th>
                    </tr>
                </thead>
                <tbody>
                  <tr>
<td data-sheets-value="{&quot;1&quot;:3,&quot;3&quot;:1}">1</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;A. B. Motors Pvt. Ltd.&quot;}">A. B. Motors Pvt. Ltd.</td>
<td data-sheets-value="{&quot;1&quot;:4,&quot;4&quot;:0}">FALSE</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;-&quot;}">-</td>
</tr>
<tr>
<td data-sheets-value="{&quot;1&quot;:3,&quot;3&quot;:2}">2</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;Accessories Supplier&quot;}">Accessories Supplier</td>
<td data-sheets-value="{&quot;1&quot;:4,&quot;4&quot;:1}">TRUE</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;-&quot;}">-</td>
</tr>
<tr>
<td data-sheets-value="{&quot;1&quot;:3,&quot;3&quot;:3}">3</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;Aditya Motors&quot;}">Aditya Motors</td>
<td data-sheets-value="{&quot;1&quot;:4,&quot;4&quot;:1}">TRUE</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;-&quot;}">-</td>
</tr>
<tr>
<td data-sheets-value="{&quot;1&quot;:3,&quot;3&quot;:4}">4</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;Battery&quot;}">Battery</td>
<td data-sheets-value="{&quot;1&quot;:4,&quot;4&quot;:1}">TRUE</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;-&quot;}">-</td>
</tr>
<tr>
<td data-sheets-value="{&quot;1&quot;:3,&quot;3&quot;:5}">5</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;Car Sales&quot;}">Car Sales</td>
<td data-sheets-value="{&quot;1&quot;:4,&quot;4&quot;:1}">TRUE</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;-&quot;}">-</td>
</tr>
<tr>
<td data-sheets-value="{&quot;1&quot;:3,&quot;3&quot;:6}">6</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;celica&quot;}">celica</td>
<td data-sheets-value="{&quot;1&quot;:4,&quot;4&quot;:0}">FALSE</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;-&quot;}">-</td>
</tr>
<tr>
<td data-sheets-value="{&quot;1&quot;:3,&quot;3&quot;:7}">7</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;Chauffeur&quot;}">Chauffeur</td>
<td data-sheets-value="{&quot;1&quot;:4,&quot;4&quot;:1}">TRUE</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;-&quot;}">-</td>
</tr>
<tr>
<td data-sheets-value="{&quot;1&quot;:3,&quot;3&quot;:8}">8</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;Dealer&quot;}">Dealer</td>
<td data-sheets-value="{&quot;1&quot;:4,&quot;4&quot;:1}">TRUE</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;-&quot;}">-</td>
</tr>
<tr>
<td data-sheets-value="{&quot;1&quot;:3,&quot;3&quot;:9}">9</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;Go Auto Pvt. Ltd&quot;}">Go Auto Pvt. Ltd</td>
<td data-sheets-value="{&quot;1&quot;:4,&quot;4&quot;:0}">FALSE</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;-&quot;}">-</td>
</tr>
<tr>
<td data-sheets-value="{&quot;1&quot;:3,&quot;3&quot;:10}">10</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;Helpline&quot;}">Helpline</td>
<td data-sheets-value="{&quot;1&quot;:4,&quot;4&quot;:1}">TRUE</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;-&quot;}">-</td>
</tr>
<tr>
<td data-sheets-value="{&quot;1&quot;:3,&quot;3&quot;:11}">11</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;Individual Buyer&quot;}">Individual Buyer</td>
<td data-sheets-value="{&quot;1&quot;:4,&quot;4&quot;:1}">TRUE</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;-&quot;}">-</td>
</tr>
<tr>
<td data-sheets-value="{&quot;1&quot;:3,&quot;3&quot;:12}">12</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;Krishana Auto Link&quot;}">Krishana Auto Link</td>
<td data-sheets-value="{&quot;1&quot;:4,&quot;4&quot;:0}">FALSE</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;-&quot;}">-</td>
</tr>
<tr>
<td data-sheets-value="{&quot;1&quot;:3,&quot;3&quot;:13}">13</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;My Car (Indore) Pvt. Ltd.&quot;}">My Car (Indore) Pvt. Ltd.</td>
<td data-sheets-value="{&quot;1&quot;:4,&quot;4&quot;:0}">FALSE</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;-&quot;}">-</td>
</tr>
<tr>
<td data-sheets-value="{&quot;1&quot;:3,&quot;3&quot;:14}">14</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;NCR Motors India Pvt. Ltd.&quot;}">NCR Motors India Pvt. Ltd.</td>
<td data-sheets-value="{&quot;1&quot;:4,&quot;4&quot;:0}">FALSE</td>
<td data-sheets-value="{&quot;1&quot;:2,&quot;2&quot;:&quot;-&quot;}">-</td>
</tr>
                    
                </tbody>
                <!--<tfoot>-->
                <!--    <tr>-->
                <!--        <th>View</th>-->
                <!--        <th>Manufacturer</th>-->
                <!--        <th>Model</th>-->
                <!--        <th>Tyre Size</th>-->
                <!--        <th>Active</th>-->
                <!--        <th>Tools</th>-->
                <!--    </tr>-->
                <!--</tfoot>-->
            </table>
            </div>
            </div>
          </div>
        </div>
      </div><!-- End Row-->
       

       <!--End Dashboard Content-->
      <!--start overlay-->
    <div class="overlay toggle-menu"></div>
  <!--end overlay-->
    </div>
    <!-- End container-fluid-->
    
    </div><!--End content-wrapper-->
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->   
   
  </div><!--End wrapper-->
  
